# Legitiv Linux 0.3.0 — embedded Termux / Linux / VNC

Это экспериментальный Android-проект, переделанный по результатам исследования GitHub на 26 сентября 2026 года.

## Главное

Пользователю не требуется отдельно устанавливать приложение Termux. В APK подключён standalone SDK `libtermux-android`, а ARM64 bootstrap включается как `libtermux-android-bootstrap-arm64`.

Архитектура:

```text
Legitiv Linux APK
│
├─ LibTermux SDK
│   └─ встроенный Termux runtime + PTY + TerminalView
│
├─ Linux OS module
│   └─ PRoot
│      ├─ Ubuntu 24.04
│      ├─ Debian 12
│      ├─ Alpine
│      └─ Kali
│
└─ DesktopSession
   └─ TigerVNC / RFB
      └─ DistroDisplay (Compose, внутри Legitiv)
```

## Важное ограничение

`libtermux-android` находится в экспериментальной стадии. Поэтому этот репозиторий следует считать MVP/исследовательской сборкой, а не готовым production SDK. Координаты Maven и API были сверены с текущей веткой проекта, но здесь не было выполнено реальное Gradle-собирание на Android SDK, поэтому 100% совместимость JitPack-артефактов не гарантируется.

## Сборка

Требуется Android Studio с поддержкой AGP 9.2.x и JDK 17.

1. Открыть папку проекта в Android Studio.
2. Выполнить Gradle Sync.
3. `Build → Build APK(s)`.
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

На устройстве Android 8+ минимум; для текущего встроенного bootstrap рассчитан профиль ARM64.

## Поведение после установки

1. Запустить Legitiv Linux.
2. Нажать «Инициализировать встроенный Termux».
3. Выбрать/настроить профиль дистрибутива.
4. Установить выбранный Linux.
5. Запустить Desktop — рабочий стол открывается в `DistroDisplay`, без Termux:X11 и без отдельного VNC-клиента.

Первый запуск выбранного дистрибутива потребует интернет: rootfs загружается отдельно. Bootstrap Termux для ARM64 входит в APK.

## Приложения

Профили Ubuntu/Debian заранее включают командные пакеты `git`, `python3`, `vlc`, `thunar`, а также базовые инструменты. Полноценность конкретной программы зависит от ARM64-сборки и возможностей графического стека.

Игры не гарантируются. Linux-native игры могут работать, если есть ARM64-совместимая сборка и графический стек. Для Windows/x86 игр нужен отдельный слой совместимости/трансляции (например Box64/Wine/FEX), которого в этой версии нет.

## Что нужно для production 1.0

Самый надёжный путь — форк официального `termux/termux-app`, изменение application/package namespace, пересборка собственного bootstrap и затем интеграция собственного UI Legitiv. Это ближе к upstream архитектуре Termux, чем зависимость от экспериментального стороннего SDK.
