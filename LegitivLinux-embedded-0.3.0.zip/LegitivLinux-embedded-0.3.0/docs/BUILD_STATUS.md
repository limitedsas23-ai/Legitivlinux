# Build status

The project source and architecture are prepared, but APK compilation is not performed in this environment because Android SDK/Gradle dependencies are not locally provisioned.

The code is therefore a buildable project candidate, not a claim of device-tested APK compatibility.

Update 0.3.0: MainActivity now matches the current libtermux API observed at commit 3a7e2ae63c4824fac384769c9afb8bc579458da9: LibTermux.init(), NativeLibBootstrapProvider, createOs(), DistroDisplay and DistroRuntimeSettings. The archive still has not been Gradle-built in this environment because an Android SDK/NDK toolchain is not provisioned here.
