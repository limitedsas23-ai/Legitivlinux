# Third-party components

Legitiv Linux 0.3.0 uses/openly references:

- Termux / termux-packages / proot-distro — see upstream license files.
- libtermux-android — Apache-2.0 according to its repository metadata.
- Jetpack Compose / AndroidX — Apache-2.0.

Before publishing an APK, include the exact LICENSE/NOTICE files from every distributed binary and source component and verify the current upstream terms.
