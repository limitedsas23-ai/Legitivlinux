# Build status — Legitiv Linux 0.3.1

## Исправлено

- убрана критическая зависимость сборки от JitPack-артефактов LibTermux;
- добавлено автоматическое получение `libtermux/libtermux-android` в `vendor/libtermux`;
- добавлено Gradle composite build с dependency substitution для Core, OS, TerminalView и ARM64 bootstrap;
- вызов инициализации приложения переведён на документированный upstream API `termux.initialize()`;
- добавлен воспроизводимый GitHub Actions workflow;
- добавлен `doctor.sh` для Termux/Linux;
- добавлен самозапускаемый `gradlew` с Gradle 9.4.1.

## Проверено здесь

- shell-скрипты проходят `bash -n`;
- YAML workflow разбирается корректно;
- структура ZIP и изменённые файлы проверены.

## Не заявляется как проверенное

APK не собирался в этом окружении: контейнер не имеет исходящего DNS/доступа для клонирования GitHub. Поэтому архив является исправленным исходным проектом и CI-рецептом, а не уже собранным APK.
