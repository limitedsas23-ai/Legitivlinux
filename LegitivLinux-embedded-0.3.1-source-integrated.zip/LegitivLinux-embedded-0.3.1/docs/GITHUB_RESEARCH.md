# GitHub research snapshot — 2026-09-26

## Primary repositories inspected

- `termux/termux-app`
- `termux/termux-packages`
- `termux/proot-distro`
- `termux/termux-gui`
- `novnc/noVNC`
- `novnc/websockify`
- `libtermux/libtermux-android` at commit `3a7e2ae63c4824fac384769c9afb8bc579458da9`

## Finding

For the requested “one Android app, no separate Termux app” UX, `libtermux/libtermux-android` is the closest existing GitHub implementation: it exposes a standalone Termux runtime, TerminalView, distro/PRoot management, and an embedded Compose VNC display.

The upstream Termux repo remains the production-grade reference: it contains the actual terminal app/bootstrap architecture and documents how to fork/rename the package and rebuild bootstrap artifacts.

## Key implementation detail

The current libtermux tree explicitly provides `bootstrap-arm64`, `bootstrap-arm`, `bootstrap-x86_64` and `bootstrap-x86` modules. Its `NativeLibBootstrapProvider` resolves the install-time-extracted binaries. This is preferable to downloading executable bootstrap files into app-private storage on modern Android.

## Current Legitiv choice

- Use the standalone SDK for the MVP.
- Use the OS module for official ARM64 distro roots.
- Use `DistroDisplay` directly instead of noVNC WebView.
- Bundle ARM64 bootstrap at APK install time.
- Download distro rootfs on demand.

## Production path

If the experimental SDK becomes a blocker, fork upstream `termux/termux-app`, rename package/application identity, rebuild bootstrap, and place Legitiv UI above the official Termux core. Do not mix APK/plugin signing ecosystems.
