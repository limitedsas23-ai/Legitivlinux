# Legitiv Linux 0.3.1 — сборка со встроенным LibTermux

В этой версии LibTermux больше не берётся как бинарный JitPack-артефакт. При сборке исходники `libtermux/libtermux-android` автоматически скачиваются в `vendor/libtermux` и подключаются через Gradle composite build.

## Android Studio / Linux / macOS / Windows

Сначала установите Git и JDK 21, затем из корня проекта выполните:

```bash
./tools/bootstrap-libtermux.sh
./gradlew :app:assembleDebug
```

APK появится здесь:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Termux на Android

Установите `git` и JDK/Gradle тем способом, которым они доступны в вашем окружении Termux, затем:

```bash
cd /путь/к/LegitivLinux-embedded-0.3.1
chmod +x tools/bootstrap-libtermux.sh
./tools/bootstrap-libtermux.sh
./gradlew :app:assembleDebug
```

Для повторяемости можно зафиксировать конкретный commit LibTermux:

```bash
LIBTERMUX_REF=<commit-or-tag> ./tools/bootstrap-libtermux.sh
```

## GitHub Actions

Workflow `Build Legitiv Linux APK` делает три вещи: получает Legitiv, скачивает LibTermux из GitHub, затем собирает `:app:assembleDebug` и публикует APK как workflow artifact.

## Что уже подключено

- LibTermux Core;
- OS module с PRoot;
- TerminalView;
- ARM64 bootstrap;
- Ubuntu 24.04;
- Debian 12;
- Alpine;
- Kali;
- встроенный XFCE/VNC display через API LibTermux.

Root не требуется: в приложении выбран `ExecutionMode.PROOT`.

Важно: upstream LibTermux сам помечает проект как экспериментальный. APK можно собрать, но реальную работу всех distro/desktop сценариев нужно отдельно проверить на устройстве.
