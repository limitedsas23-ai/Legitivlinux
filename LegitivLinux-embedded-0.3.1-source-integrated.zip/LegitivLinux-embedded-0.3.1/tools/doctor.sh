#!/usr/bin/env bash
set -u

ok=0
warn=0
err=0
check_cmd() {
  local name="$1" cmd="$2"
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "[OK]   $name: $(command -v "$cmd")"
    ok=$((ok+1))
  else
    echo "[MISS] $name: install '$cmd'"
    err=$((err+1))
  fi
}

check_cmd Git git
check_cmd Curl curl
check_cmd Unzip unzip
check_cmd Java java

if command -v java >/dev/null 2>&1; then
  java -version 2>&1 | head -n 1
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ -d "$ROOT/vendor/libtermux/.git" ]]; then
  echo "[OK]   LibTermux source: present ($(git -C "$ROOT/vendor/libtermux" rev-parse --short HEAD 2>/dev/null || echo unknown))"
  ok=$((ok+1))
else
  echo "[WARN] LibTermux source is not prepared; run ./tools/bootstrap-libtermux.sh"
  warn=$((warn+1))
fi

echo "Result: OK=$ok WARN=$warn MISS=$err"
[[ $err -eq 0 ]]
