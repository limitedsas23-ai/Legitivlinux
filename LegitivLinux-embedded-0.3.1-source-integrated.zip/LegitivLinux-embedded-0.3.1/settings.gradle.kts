pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Kept for non-LibTermux dependencies used by the app.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "LegitivLinuxEmbedded"
include(":app")

// LibTermux is consumed as a source dependency instead of a JitPack binary.
// This avoids the 401/artifact-resolution failure previously seen in CI.
val libTermuxDir = file("vendor/libtermux")
if (libTermuxDir.isDirectory) {
    includeBuild(libTermuxDir) {
        dependencySubstitution {
            substitute(module("com.github.libtermux:libtermux-android"))
                .using(project(":core"))
            substitute(module("com.github.libtermux:libtermux-os"))
                .using(project(":os"))
            substitute(module("com.github.libtermux:terminal-view"))
                .using(project(":terminal-view"))
            substitute(module("com.github.libtermux:libtermux-android-bootstrap-arm64"))
                .using(project(":bootstrap-arm64"))
        }
    }
}
