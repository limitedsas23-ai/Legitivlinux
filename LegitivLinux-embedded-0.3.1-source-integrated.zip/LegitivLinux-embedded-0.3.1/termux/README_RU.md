# Встроенный Termux runtime

Эта версия Legitiv Linux не обращается к установленному на телефоне `com.termux`. Терминальный runtime находится внутри самого APK через embedded LibTermux.

После первого запуска LibTermux раскладывает свой bootstrap в приватное хранилище приложения. Затем `Legitiv Linux` управляет пакетами и Linux-дистрибутивами через собственный bridge.

## Подготовка профиля

После инициализации выполните из UI команды `2–4`. Вручную те же команды:

```bash
pkg update -y
pkg install -y proot-distro python git wget curl
proot-distro install ubuntu:24.04
legitiv-setup ubuntu
```

Для VNC-пароля:

```bash
proot-distro login ubuntu -- vncpasswd
```

Затем:

```bash
legitiv-desktop ubuntu
```

Legitiv WebView подключается к `ws://127.0.0.1:6080`, а websockify проксирует на `127.0.0.1:5901`.
